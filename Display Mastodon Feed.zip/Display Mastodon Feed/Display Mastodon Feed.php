<?php
/*
Plugin Name: Display Mastodon Feed
Description: Fetch and display Mastodon feed.
Version: 1.0
Author: Your Name
*/

function fetch_mastodon_timeline($domain, $user_id = '109377937238865211', $limit = 5) {
    // Use the provided user ID to fetch the statuses
    $user_id = get_option('mastodon_user_id', '0');
    $api_url = "https://{$domain}/api/v1/accounts/{$user_id}/statuses?limit={$limit}";
    $response = wp_remote_get($api_url);

    if (is_wp_error($response)) {
        error_log('Error fetching statuses: ' . $response->get_error_message());
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    $data = json_decode($body, true);

    return $data;
}

function display_mastodon_feed($domain, $user_id = '109377937238865211', $limit = 5) {
    $data = fetch_mastodon_timeline($domain, $user_id, $limit);

    if (!$data) {
        return false;
    }

    $output = '<ul class="mastodon-feed">';

    foreach ($data as $status) {
        $avatar = $status['account']['avatar'];
        $username = "@" . ($status['account']['display_name'] ?: $status['account']['username']); // Use display name, fallback to username

        $output .= '<li>';

        $output .= "<div class='mastodon-header'>";
        $output .= "<img src='{$avatar}' alt='avatar' class='mastodon-avatar'>";
        $output .= "<span class='mastodon-username'>{$username}</span>"; // Display the username right after the avatar
        $output .= "</div>";

        $output .= '<div class="mastodon-body">';
        $output .= '<a href="' . $status['url'] . '" class="mastodon-content">';
        $output .= $status['content'];
        $output .= '</a>';

        // Add images if present
        if (isset($status['media_attachments']) && count($status['media_attachments']) > 0) {
            foreach ($status['media_attachments'] as $attachment) {
                if ($attachment['type'] === 'image') {
                    $output .= "<img src='{$attachment['url']}' alt='{$attachment['description']}' class='mastodon-image'>";
                }
            }
        }

        $output .= "</div>";
        $output .= '</li>';
    }

    $output .= '</ul>';  // Close the ul tag here
    return $output;  // Return the output here, after the loop
}

function mastodon_feed_shortcode($atts) {
    $atts = shortcode_atts(
        array(
            'domain'   => 'techopolis.social',
            'limit'    => 5,
        ),
        $atts,
        'mastodon_feed'
    );

    $statuses = fetch_mastodon_timeline($atts['domain'], '109377937238865211', $atts['limit']);

    // Log statuses or errors for debugging
    error_log('Fetched data: ' . print_r($statuses, true));

    if (!$statuses || !is_array($statuses)) {
        error_log('Unexpected statuses structure. Fetched data: ' . print_r($statuses, true));
        return "Failed to fetch Mastodon feed.";
    }

    $output = "<ul class='mastodon-feed'>";
    foreach ($statuses as $status) {
        // Check if $status is an array and if 'content' key exists
        if (is_array($status) && isset($status['content'])) {
            $output .= "<li>{$status['content']}</li>";
        } else {
            error_log('Unexpected individual status structure: ' . print_r($status, true));
        }
    }
    $output .= "</ul>";

    return $output;
}
add_shortcode('mastodon_feed', 'mastodon_feed_shortcode');

function mastodon_feed_styles() {
    echo "
    <style>
        .mastodon-feed {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr)); /* This will create a responsive grid */
            gap: 20px;
            list-style-type: none;
            padding: 0;
            margin: 0;
        }

        .mastodon-feed li {
            border: 1px solid #e1e1e1;
            padding: 15px;
            display: flex;
            flex-direction: column; /* Changed from row to column for grid layout */
            align-items: center;
            border-radius: 10px; /* Rounded corners for each grid item */
        }

        .mastodon-avatar {
            border-radius: 50%;
            width: 50px;
            height: 50px;
            margin-bottom: 15px; /* Changed from margin-right */
            object-fit: cover;
        }

        .mastodon-content {
            font-size: 16px;
            color: #333;
            text-decoration: none;
            text-align: center;
        }

        .mastodon-content:hover {
            text-decoration: underline;
        }
    </style>
    ";
}
add_action('wp_head', 'mastodon_feed_styles');

function mastodon_feed_register_settings() {
    register_setting('mastodon_feed_options_group', 'mastodon_user_id');
}
add_action('admin_init', 'mastodon_feed_register_settings');

//  Create the settings page.
function mastodon_feed_create_menu() {
    add_menu_page(
        'Mastodon Feed Settings', 
        'Mastodon Feed', 
        'administrator', 
        'mastodon_feed_settings', 
        'mastodon_feed_settings_page'
    );
}
add_action('admin_menu', 'mastodon_feed_create_menu');

// Display the setting fields.
function mastodon_feed_settings_page() {
    ?>
            <h2>How to find your Mastodon User ID</h2>
        <p>
            To locate your Mastodon User ID, follow these steps:
        </p>
        <ol>
            <li>Visit this link: <a href="https://example.com/api/v2/search?q=you@yourdomain.com&resolve=true&limit=5" target="_blank">https://example.com/api/v2/search?q=you@yourdomain.com&resolve=true&limit=5</a></li>
            <li>Replace <code>you@yourdomain.com</code> with your Mastodon username and domain. For instance, if your Mastodon username is "john" and you're on the "mastodon.social" instance, you'd replace it with <code>john@mastodon.social</code>.</li>
            <li>After visiting the modified link, you'll receive a JSON response. Look for the <code>id</code> field under the account details. This is your Mastodon User ID.</li>
            <li>Copy that ID and paste it in the "Mastodon User ID" field above.</li>
        </ol>
    </div>

    <div class="wrap">
        <h2>Mastodon Feed Settings</h2>
        <form method="post" action="options.php">
            <?php settings_fields('mastodon_feed_options_group'); ?>
            <table class="form-table">
                <tr valign="top">
                <th scope="row"><label for="mastodon_user_id">Mastodon User ID</label></th>
                <td><input type="text" id="mastodon_user_id" name="mastodon_user_id" value="<?php echo esc_attr(get_option('mastodon_user_id')); ?>" /></td>
                </tr>
            </table>
            <?php submit_button();
            ?>
        </form>
    </div>

    <?php
}

// Display a notice in the WP admin.
function mastodon_feed_admin_notice() {
    $user_id = get_option('mastodon_user_id');
    if (!$user_id) {
        echo '<div class="notice notice-warning is-dismissible">
            <p>In order to use Display Mastodon Feed, you must <a href="' . admin_url('admin.php?page=mastodon_feed_settings') . '">set it up</a>.</p>
        </div>';
    }
}
add_action('admin_notices', 'mastodon_feed_admin_notice');
?>